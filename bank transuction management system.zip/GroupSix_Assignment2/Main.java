import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class BankAccount {
    private double balance;
    private int correctPin;
    private String accountNumber;

    // Constructor initializes balance
    public BankAccount(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    // Return the correct User Pin
    public int setPin(){
        this.correctPin = 1234;
        return correctPin;
    }

    // Deposit method
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            JOptionPane.showMessageDialog(null, "Cash Deposit of UGX " +amount+ " was successful!!\n New Balance: UGX " + balance, "CASH DEPOSIT", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Enter a valid amount!", "Invalid Withdrawal", JOptionPane.ERROR_MESSAGE);
            // return balance;
        }
    }

    // Withdraw method
    public void withdraw(double amount) {
        double tax = amount * (1.5/100);
        double withdrawFee = amount + tax;
        if (withdrawFee <= 0) {
            JOptionPane.showMessageDialog(null, "Enter a valid amount\n"+"Current balance: UGX "+ balance,"Withdrawal failed!!", JOptionPane.ERROR_MESSAGE);
        } else if (withdrawFee > balance) {
            JOptionPane.showMessageDialog(null, "INSUFFICIENT FUNDS\n Current balance: UGX "+ balance, "Withdrawal failed!!", JOptionPane.ERROR_MESSAGE);
        } else {
            balance -= withdrawFee;
           JOptionPane.showMessageDialog(null,
                "Withdrawn: UGX " + amount + "\nTax: UGX " + tax + "\nNew Balance: UGX " + balance,
                "CASH WITHDRAWAL", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Check balance
    public double getBalance() {
        return balance;
    }

    // Get account number
    public String getAccountNumber() {
        return accountNumber;
    }
}

class GUI extends JFrame implements ActionListener {
    private BankAccount account;
    private JTextField amountField;
    private JLabel balanceLabel;
    private JButton depositBtn, withdrawBtn, checkBtn, exitBtn;


    // Constructor
    public GUI() {
        account = new BankAccount("A1029900", 0.00);

        // Basic window setup
        setTitle("Bank Transaction Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(245, 245, 250));

        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setPreferredSize(new Dimension(400, 60));
        titlePanel.setBackground(new Color(70, 130, 180));
        titlePanel.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Welcome to DFCU Bank Services", SwingConstants.CENTER);
        titleLabel.setForeground(Color.RED);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
        add(titlePanel, BorderLayout.NORTH);
        

        //Top section (Balance display) 
        balanceLabel = new JLabel("Balance: UGX " + account.getBalance(), SwingConstants.CENTER);
        balanceLabel.setFont(new Font("Arial", Font.BOLD, 20));
        balanceLabel.setForeground(new Color(0, 25, 182));
        add(balanceLabel, BorderLayout.NORTH);

        //Center section (Amount input)
        JPanel centerPanel = new JPanel(new FlowLayout());
        amountField = new JTextField(20); 
        amountField.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(new JLabel("Enter Amount:"));
        centerPanel.add(amountField);
        add(centerPanel, BorderLayout.CENTER);

        // Bottom section (Buttons)
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 10, 10));

        depositBtn = new JButton("Deposit");
        withdrawBtn = new JButton("Withdraw");
        checkBtn = new JButton("Check Balance");
        exitBtn = new JButton("Exit");

         // Button styling
        depositBtn.setBackground(new Color(30, 250, 70));
        withdrawBtn.setBackground(new Color(255, 30, 20));
        checkBtn.setBackground(new Color(70, 50, 200));
        exitBtn.setBackground(new Color(105, 105, 105));

        // Adds padding around the buttons
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));


        // Add buttons to grid
        buttonPanel.add(depositBtn);
        buttonPanel.add(withdrawBtn);
        buttonPanel.add(checkBtn);
        buttonPanel.add(exitBtn);

        add(buttonPanel, BorderLayout.SOUTH);

        // Add listeners
        depositBtn.addActionListener(this);
        withdrawBtn.addActionListener(this);
        checkBtn.addActionListener(this);
        exitBtn.addActionListener(this);
    }

    // Handle button clicks
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == depositBtn) {
            double amount = getAmount();
            account.deposit(amount);
            updateBalance();
        } else if (e.getSource() == withdrawBtn) {
            double amount = getAmount();
            account.withdraw(amount);
            updateBalance();
        } else if (e.getSource() == checkBtn) {
            JOptionPane.showMessageDialog(this, "Your current balance is UGX " + account.getBalance());
        } else if (e.getSource() == exitBtn) {
            JOptionPane.showMessageDialog(this, "Thank you for using our bank!");
            System.exit(0);
        }
    }

    // Helper method to get amount
    private double getAmount() {
        try {
            return Double.parseDouble(amountField.getText());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number!");
            return 0;
        }
    }

    // Update balance label
    private void updateBalance() {
        balanceLabel.setText("Balance: UGX " + account.getBalance());
        amountField.setText("");
    }
}

public class Main{
     // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankAccount obj = new BankAccount("AC100910320", 0.00);
        boolean isRunning = true;

        do
        {
            // Prompts user for pin
            System.out.print("Enter your pin: ");
            int pin = scanner.nextInt();
            if(obj.setPin() == pin)
            {
                new GUI().setVisible(true);
            }
            else{
                System.out.println("Incorrect Pin!! ");
            }
        }
        while(isRunning == true);
    }
}