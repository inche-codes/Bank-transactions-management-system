**********************BANK TRANSACTION MANAGEMENT SYSTEM*********************
This program allows a user to perform simple banking operations through a Graphical User Interface (GUI).

**HOW TO USE**
Run the program.
When prompted in the console, enter your PIN  (1234).
The banking window will open.

In the GUI,
Enter an amount in the text field.
Click Deposit to add money.
Click Withdraw to take out money (1.5% fee applies).
Click Check Balance to view your current balance.
Click Exit to close the program.

Note:
Invalid or negative amounts are not accepted.
The system shows messages for all transactions using pop-up dialogs.